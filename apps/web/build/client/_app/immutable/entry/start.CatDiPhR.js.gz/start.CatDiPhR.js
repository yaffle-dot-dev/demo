import{l as o,a as r}from"../chunks/DZ2OXfsk.js";export{o as load_css,r as start};
