export async function handler() { return { statusCode: 200, body: "placeholder — deploy scanner to replace" } }
